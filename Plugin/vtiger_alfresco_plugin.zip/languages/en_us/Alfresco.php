<?php

$languageStrings = array(
	'Alfresco' => 'Alfresco'
);
