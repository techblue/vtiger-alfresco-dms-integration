<?php

        header('location:index.php?module=Alfresco&view=selectfromalfresco');
    