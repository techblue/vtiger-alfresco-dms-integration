<?php

  //global $session, $store;
global $repositoryUrl;
    global $folderPath;
    global $hostname;
    global $limit_doc;
    global $limit_fol;
    $limit_doc=25;
    $limit_fol=15;
    //your host name ex-> www.example.com
  $hostname='';
 // $foldername='alfresco_vtigercrm';
  $repositoryUrl = "http://".$hostname."/alfresco/cmisatom";
  
  //this shows company home
  $folderPath='/';
?>
